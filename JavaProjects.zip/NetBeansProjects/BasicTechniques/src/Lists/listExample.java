package Lists;

import java.util.ArrayList;
import java.util.Collections;
public class listExample {
    
    public static void main(String[] args) {
        //create array list
        //declare
        ArrayList<String> studentNames;
        studentNames= new ArrayList<> ();
        //add values to array list
        studentNames.add("Santa");
        studentNames.add("Penjamin");
        studentNames.add("Leck");
        studentNames.add("Fanta");
        studentNames.add("Aaran");
        //pritning out all values
        System.out.println(studentNames);
        
        //for- each loop print 
        //improvement as this is a formatted line
        for(String studentName:studentNames){
            System.out.println(studentName);
            
       
        }

//similar to an array we can use a readily available method to sort out
//the ArrayList as follows


//sorting the ArrayList

Collections.sort(studentNames);

                
 
    }
    
}
