package Lists;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class listTasks {

    public static void main(String[] args) {
        //array list
        ArrayList<String> studentNames;
        studentNames = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        String word;

        for (int i = 0; i < 20; i++) {
            System.out.println("Enter a name : ");
            word = sc.nextLine();
            char[] arr = word.toCharArray();
            if ((int) arr[0] >= 97 && (int)arr[0] <= 127 ){
  
                arr[0] = (char) ((int) arr[0] - 32);
                
            }
                
            
            studentNames.add(word);

        
        }
      sc.close();
      
       for(String studentName:studentNames){
            System.out.println(studentName);
          
         
          
          
          
          
      }
      
        
      

    

}
}
