
package dataTypes;

public class Characters1 {
     public static void main(String[] args) {
         System.out.println("Investigating char data type");
         
         //declaration and assignments
         char letter1 = 'a';
         char letter2 = 'h';
        
         //investigation 'concatenation'
         System.out.println(letter1+ letter2);
         //actual concatention with strring inbetween them
         System.out.println(letter1 + " " + letter2);
         
         //declaration and assignment
         
         char b = 10243;
         char two = 9731;
         char three = 9108;
         char four = 10000;
         //using empty string to invoke concatenation
         System.out.println("" + b + two +  three + four);
                 
           
               
       
        
     }
    
}
