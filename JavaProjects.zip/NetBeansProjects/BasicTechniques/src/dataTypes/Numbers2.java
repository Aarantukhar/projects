
package dataTypes;

public class Numbers2 {
     public static void main(String[] args) {
         System.out.println("Investigating numbers part 2 ");
         
         //declaration
         
         double height = 3.5;
         double width = 4.0;
         double radius = 7.5;
         double area;
         
         area = height * width;
                 
         System.out.println("The area o the rectangle is " + area);
         
         radius = (double) Math.pow(radius, 2);
         //getting pi 
         area = 3 * Math.PI * radius;
         //rounds to 2.dp
         double round = (double) Math.round(area*100)/100 ;
        //output
   System.out.println("The area of the circle is " + round);
        
          int x = 5;
          int y = 3;
          int w;
          double z;
          
          w = x + y;
          z = x + y;
          
        System.out.println(w);
        System.out.println(z);
               
     }
    
}



