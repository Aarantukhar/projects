
package dataTypes;

public class Numbers1 {
   public static void main(String[] args) {
       //output
       System.out.println("Invesigating int");
       //declarations
       int num1;
       int num2;
       int num3;
       int num4;
       int result;
       //assignments
       num1 = 100;
       num2 = 5;
       num3 = -70;
       num4 = 90;
       
       //calculations
       result = num1 - (3 * num3);
       //concatenation
       System.out.println(num1 + " - (3 *  " + num3 + ") = " + result);
       //divison
       result = num1/num2;
       System.out.println(num1 +  " DIV " + num2 + " = " + result);
       //absolute value
       result = num1/ Math.abs(num3);
       System.out.println(num1 + " DIV abs(" + num3 + ") = " + result);
       //exponentiation
       double resultDouble = Math.pow(num2, 3);
       System.out.println(num2 + " ^ 3 = " + result);
        
       result = (int) Math.pow(2,30);
       //result
       int result2;
       result2 = (int) Math.pow(2,31);
       
       // assinging to long 
       long num5;
       num5 = (long) Math.pow(2,32);
       
       long light;
       light = (long) Math.pow(3 * 10, 8) * 355839;
       System.out.println(light + "m");
         
       
       
       
         
   
 
   
    
    
    }
}
