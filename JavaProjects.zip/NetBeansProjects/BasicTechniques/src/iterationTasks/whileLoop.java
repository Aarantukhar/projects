/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iterationTasks;

/**
 *
 * @author 18Atukhar
 */
public class whileLoop {
    public static void main(String[] args){
        //while example
        int n = 10;
        while(n>0) {
            System.out.println("tick " + --n);
            
        }
    }
}
   
    

 

