package iterationTasks;

public class iteration1 {
    

        
        /* @SuppressWarnings("empty-statement")*/
    public static void main(String[] args) {
        
        //task 1
        
      

        for (int i = 0; i < 10; i++) {

            System.out.println("I is " + i);
        }
        
        //task 2
        
        for (int i = 10; i > 0; i = i-1){
            
            System.out.println("I is " + i);
        }
        
        //task 3
        
            
        
        //declare an array
        int[] nums = {1, 2, 3, 4, 5};
        //declare sum 
        int sum = 0;
        for (int i = 0; i < nums.length; i++) {
            sum+= nums[i];
        }
        System.out.println(sum);
        //sum
        sum = 0;
        //for each statement
        for (int num : nums) {
            sum += num;
            
        }
        //output
        System.out.println(sum);

    }
}
