package Starters;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class starter3 {
    
    static int dim;

    public static void main(String[] args) {
        dim = 9;

        int arr[];
        arr = new int[dim];
        
        boolean breaker = false;
        int count = 0;

       for (int x = 0; x < arr.length - 1;x++){
                Scanner sc = new Scanner(System.in);
                Integer num;

                System.out.print("Enter result: ");
                num = sc.nextInt();
                arr[x] = num;

       
                
            }
            int largestInt = largestInt(arr);
            int store = 0;
            for(int i = 0;i < arr.length - 1; i++){
                store = store + arr[i];
                
            }
            int sum = store * largestInt;
          
            System.out.println(sum);   
            writeFile(sum);
                
        }
    
            
   private static void writeFile(int sum){         
           try {
      FileWriter myWriter = new FileWriter("\\\\tts-data2\\StudentData\\18ATukhar\\NetBeansProjects\\BasicTechniques\\src\\names2_1.txt");
      myWriter.write(sum);
      myWriter.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }     
   }             
                
            
        
     
    
    private static int largestInt(int arr[]){
          int temp = 0;
        int n = arr.length;

        //go through the  array and checks if last value was bigger than the next
        for (int s = 0; s < n; s++) {
            for (int j = 1; j < (n - s); j++) {
                if (arr[j - 1] > arr[j]) {
                    //swap elements in the array
                    temp = arr[j - 1];
                    arr[j - 1] = arr[j];
                    arr[j] = temp;
       
            }
                
        
    }

}
       int bigValue;
       bigValue = arr[8];
        return bigValue;
    }
}
