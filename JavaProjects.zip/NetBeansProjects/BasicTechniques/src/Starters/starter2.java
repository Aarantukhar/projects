package Starters;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class starter2 {

   // global variable
    static int dim;
    
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // declarations
        int[][] arr;
        String fileName = "\\\\tts-data2\\StudentData\\18ATukhar\\NetBeansProjects\\BasicTechniques\\src\\hundred.txt";
        dim = 100;
        arr = new int[dim][dim];

        loadData(arr, fileName);

        printArray(arr);

        // find the biggest col and row totals and positions
        int[] colResults = findBigCol(arr);
        int[] rowResults = findBigRow(arr);
        
        // compare row against column
        if (rowResults[0] > colResults[0]) {
            System.out.println("Row " + rowResults[1] + " has biggest "
                    + "total = " + rowResults[0]);
        } else if (colResults[0] > rowResults[0]) {
            System.out.println("Col " + colResults[1] + " has biggest "
                    + "total = " + colResults[0]);            
        } else {
            System.out.println("Equal values");
            System.out.println("Row " + rowResults[1] + " has biggest "
                    + "total = " + rowResults[0]);
            System.out.println("Col " + colResults[1] + " has biggest "
                    + "total = " + colResults[0]);            
        }

    }

    // file operations - subroutine to load 2d array with int data from file
    private static void loadData(int[][] arr, String fileName) throws FileNotFoundException, IOException {

        BufferedReader br = new BufferedReader(new FileReader(fileName));
        int value;

        for (int row = 0; row < dim; row++) {
            for (int col = 0; col < dim; col++) {
                // get the integer from the file
                value = Integer.valueOf(br.readLine());
                arr[row][col] = value;
            }
        }
        br.close();
    }

    private static void printArray(int[][] arr) {
        for (int[] is : arr) {
            for (int i : is) {
                System.out.print(i + "\t");
            }
            System.out.println();
        }
    }

    private static int calcColTotal(int[][] arr, int col) {
        int result = 0;
        // go through the rows for this column to create total
        for (int row = 0; row < arr.length; row++) {
            result += arr[row][col];
        }
        return result;
    }

    // subroutine to find biggest col total and position
    private static int[] findBigCol(int[][] arr) {
        // go through all columns - find the biggest
        int colMax = -1;
        int colNum = -1;
        int colTotal = -1;
        for (int col = 0; col < arr.length; col++) {
            colTotal = calcColTotal(arr, col);
            // replace maximum
            if (colTotal > colMax) {
                colMax = colTotal;
                colNum = col;
            }
        }
        int[] results = {colMax, colNum};
        return results;
    }
    private static int calcRowTotal(int[][] arr, int row) {
        int result = 0;
        // go through the rows for this column
        for (int col = 0; col < arr[0].length; col++) {
            result += arr[row][col];
        }
        return result;
    }

    // subroutine to find biggest col total and position
    private static int[] findBigRow(int[][] arr) {
        // go through all columns - find the biggest
        int rowMax = -1;
        int rowNum = -1;
        int rowTotal = -1;
        for (int row = 0; row < arr[0].length; row++) {
            rowTotal = calcRowTotal(arr, row);
            // replace maximum
            if (rowTotal > rowMax) {
                rowMax = rowTotal;
                rowNum = row;
            }
        }
        int[] results = {rowMax, rowNum};
        return results;
    }
}


  


    
