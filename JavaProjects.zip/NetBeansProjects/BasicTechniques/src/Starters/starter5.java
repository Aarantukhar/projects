package Starters;

public class starter5 {
    public static void main(String[] args) {
        //declaration
        String  word = "word";
        System.out.println(isValidLen(word));
        
        
       
    }
    //check length of word
    private static boolean validLength(String word){
        return word.length() >= 8 && word.length() <= 14;
            
        
    }
    //check if it passes both checks
    private static boolean isValidLen(String word) {
        return isValidLen(word) && hasUnderscore(word);
    }
    
    //check for underscore
    private static boolean hasUnderscore(String word) {
        for (int i = 0; i < word.length(); i++) {
            if(word.charAt(i) ==  '_'){
                return true;
                
            }
            
        }
        return false;
    }
    
    
    
}
