/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Starters;


public class starter {

    public static void main(String[] args) {
        int i;
        int value = 0;
        //for loop
        for(i = 8;i < 1000000;i += 8){
        //if statements to select for shell numbers
        if ((i%7) != 0) {
            if ((i%17)!= 0) {
                System.out.println(i);
                //adds shell numbers over 10000 and 123456 
                if(i>1000 && i < 123456){
                    value += i;
            }
            
            
        }
        
    }
    }
        System.out.println(value);
}
}
    

