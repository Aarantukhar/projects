package Starters;

import java.util.ArrayList;
import java.util.Arrays;

public class starter4 {

    public static void main(String[] args) {
        //declaring lists and variables
        ArrayList<Integer> randList;
        randList = new ArrayList<>();
        ArrayList<Integer> desList;
        desList = new ArrayList<>();
        int capacity = 5;
        int limit = 5;
        //calling subroutines
        randList = populate(capacity, limit);
        desList = despopulate(capacity, limit);
        printList(randList);
        printList(desList);

    }

    //populate array with random numbers
    public static ArrayList<Integer> populate(int capacity, int limit) {
        ArrayList<Integer> list;
        list = new ArrayList<>();
        //adds random numbers to list using .add method.
        for (int i = 0; i < capacity; i++) {
            list.add((int) (Math.random() * capacity));

        }
        //return list
        return list;
    }

    public static ArrayList<Integer> despopulate(int capacity, int limit) {
        ArrayList<Integer> list;
        list = new ArrayList<>();

        for (int i = 0; i < capacity; i++) {
            list.add((int) (Math.random() * capacity));

        }
        //.size is just .length but for lists instead
        int temp = 0;
        int n = list.size();

        //go through the  array and checks if last value was smaller than the last.
        for (int s = 0; s < n; s++) {
            for (int j = 1; j < (n - s); j++) {
                if (list.get(j - 1) < list.get(j)) {
                    //swap elements in the array
                    list.set(j - 1, list.get(j - 1));
                    list.set(j - 1, list.get(j));
                    list.set(j, temp);
                }
            }
        }
        return list;

    }

    public static void printList(ArrayList<Integer> list) {
        //easier/fraud way of printing list instead of for loop and .get.
        System.out.println(Arrays.toString(list.toArray()));

    }

}
