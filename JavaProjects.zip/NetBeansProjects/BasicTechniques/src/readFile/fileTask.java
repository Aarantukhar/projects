package readFile;

import java.io.FileNotFoundException;
import java.io.File;
import java.util.Scanner;



public class fileTask {

    
    public static void main(String[] args) {
        int count = 0;
        int seven = 0;
        int x = 0;
        int [] arr;
        
        //will try to find the file
       try {
        //get file
        File myObj = new File("\\\\tts-data2\\StudentData\\18ATukhar\\NetBeansProjects\\BasicTechniques\\src\\names2.txt");
        //read file
        Scanner myReader = new Scanner(myObj);
        //read line
        while (myReader.hasNextLine()) {
            //read data
            String data = myReader.nextLine();
            count++;
            if(data.length() >= 7){
                seven++;
            
            }
            //converts to array, goes through if it finds x it will break
            char [] charArray = data.toCharArray();
            for (int i = 0; i < charArray.length; i++){
                //assign characters to positions in the arrau
                if (charArray[i] == 'x' || charArray[i] == 'X'){
                    x++;
                    break;
                }
                
            int[] firstLetterFrequency = new int[26]; 

while (myReader.hasNextLine()) { 
String name = myReader.nextLine().trim(); 
if (!name.isEmpty() && Character.isLetter(name.charAt(0))) { 
char firstLetter = Character.toLowerCase(name.charAt(0)); 
 firstLetterFrequency[firstLetter - 'a']++; } } 
// Step 4: Find most frequent first letter
char mostFrequentLetter = 'a'; 
int maxFrequency = 0; 
for (i = 0; i < 26; i++) { 
if (firstLetterFrequency[i] > maxFrequency) { 
 maxFrequency = firstLetterFrequency[i];
 mostFrequentLetter = (char) ('a' + i);
 }
 } 


 System.out.println("Most frequent first letter: " + mostFrequentLetter);

                
              
}


            
          
            
          
            
        }
        //close file
        myReader.close();
        //if it cant find the file this is the error it will show
       } catch (FileNotFoundException e){
           System.out.println("An error occcurred");
           e.printStackTrace();
       }
       
       //output
       System.out.println(count);
       System.out.println(seven);
        System.out.println(x);
       
       
        
        
    
        
        
        
    
        
        
        
        
        
        
        
    }

}
