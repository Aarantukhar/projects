// package or folder declaration
package Printing;

// class or file name
public class PrintingTask1 {
    //printing task
    public static void main(String[] args) {
        //creating variable
        String testing;
        //assign value to the variable
        testing = "Just Testing";
        //this will print whatever is in the quotations
        System.out.print("test1");
        System.out.print("test2");
        //this will print on seperate lines
        System.out.println("\nline\nline\nline");
    }
    
}
