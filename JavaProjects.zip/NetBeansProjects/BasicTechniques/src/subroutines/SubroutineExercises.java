package subroutines;

public class SubroutineExercises {

    public static void main(String[] args) {
        //declarations
        int area;
        int length = 20, height = 5;
        //call the function
        area = calcRectArea(length, height);
        //print
        System.out.println(area);
        

    }

    //methods
    static int calcRectArea(int len, int hei) {
        int area = len * hei;
        //return the result
        return area;

    }
}
