package subroutines;
public class FunnctionTask {

   
    public static void main(String[] args) {
        //declarations
        int weeklyWage = 5;
        int annualWage;
        
     //call upon the function
     annualWage = calcYearIncnome(weeklyWage);
     System.out.println(annualWage);
    }

    private static int calcYearIncnome(int weeklyWage) {
        int annual;
        annual = 52 * weeklyWage;
        return annual;
        
    }
    
}
