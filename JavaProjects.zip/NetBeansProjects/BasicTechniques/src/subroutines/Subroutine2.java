
package subroutines;

public class Subroutine2 {

    public static void main(String[] args) {
    
     int factorial = 3;
     
    int d = fact(factorial);
        System.out.println(d);
     
  
     

     
     
     
     
     
    }
    private static int fact(int value){
      int total = 1;
      for (int i = value;i > 0; i--){
          total *= i;
                  }
      return total;
       
          
}
  
}

