package subroutines;

public class tasks {
    public static void main(String[] args) {
       //task 1
        double sideA = 21;
        double sideB = 23;
        //calling subroutine
      double c = hypontenuseCalculator(sideA, sideB);
        System.out.println(c);
     
     

    }
    
    private static double hypontenuseCalculator(double a, double b){
        double hypotenuse = (a*a) + (b*b);
        return hypotenuse;
        
    }
   
}


