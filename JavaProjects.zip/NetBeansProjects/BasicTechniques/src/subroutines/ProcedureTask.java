
package subroutines;

public class ProcedureTask {

    public static void main(String[] args) {
        //delcarations
        String name = "Truly humble under God";
        //call the procedure
      printGreeting(name);
      
        
       
    }
    static void printGreeting(String x){
        String message = "Good morning " + x;
        //print out the message
        System.out.println(message);
    }
}
