package tasks;

import java.util.ArrayList;
import java.util.Arrays;

public class josephusProblem {

    public static void main(String[] args) {
        ArrayList<Integer> soldierList;
        soldierList = new ArrayList<>();

        int soldierNum = 6;

        for (int i = 0; i < soldierNum; i++) {
            soldierList.add(i + 1);
        }

        int k = 1;

        System.out.println(Arrays.toString(soldierList.toArray()));

        for (int i = 0; i < soldierList.size(); i++) {

            if (i + k >= soldierList.size()&& soldierList.size() % 2 != 0) {
                i = 0;
                k = 1;
                soldierList.remove(i);
                System.out.println(Arrays.toString(soldierList.toArray()));

            }
            
            if (i + k >= soldierList.size()&& soldierList.size() % 2 == 0){
            i = 0;
            k = 1;
            soldierList.remove(i + k);
            
            
        }
            if(i > soldierList.size()){
                i = 0;
            }
            
            

            soldierList.remove(i + k);
            System.out.println(Arrays.toString(soldierList.toArray()));

        }

    }

}
