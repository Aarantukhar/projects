package tasks;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class passGen {

    
    public static void main(String[] args) {
        
        //get random words from lists
 
        String fileName = "\\\\tts-data2\\StudentData\\18ATukhar\\NetBeansProjects\\BasicTechniques\\src\\FiveLetterWords.txt";
        ArrayList<String> arr = new ArrayList<>();
        arr.add(firstWord(fileName));
        String sixWords = "\\\\tts-data2\\StudentData\\18ATukhar\\NetBeansProjects\\BasicTechniques\\src\\sixWords.txt";
        arr.add(firstWord(sixWords));
        String eightWords = "\\\\tts-data2\\StudentData\\18ATukhar\\NetBeansProjects\\BasicTechniques\\src\\eightWords.txt";
        arr.add(firstWord(eightWords));
        
        System.out.println(arr);
        
        
        
    }

  
 static String firstWord(String fileName){
     ArrayList<String> array = new ArrayList<>();
     
     //get file 
     
      try {
        //get file
        File myObj = new File(fileName);
        //read file
        Scanner myReader = new Scanner(myObj);
        //add line to arraylist
        while (myReader.hasNextLine()) {
           array.add(myReader.nextLine());
     
 }
        Random rand = new Random();
        //goes to a random position into an array
        int randomIndex = rand.nextInt(array.size());
       return (array.get(randomIndex));
    
}       catch (FileNotFoundException ex) {
            Logger.getLogger(passGen.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
     
 }
}
