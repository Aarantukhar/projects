import java.util.Arrays;

public class collectorsProblem {

    public static void main(String[] args) {
       
        int numCards = 6;

        //how many tests
        int numTests = 10000;

        //store the number of packets bought for each test
        int[] packetsBoughtArray = new int[numTests];

        //carry out tests
        for (int i = 0; i < numTests; i++) {
            packetsBoughtArray[i] = CollectingCardsTest(numCards);
        }

        //print the mean number of packets bought
        double meanPackets = calculateMean(packetsBoughtArray);
        System.out.println("Mean number of packets bought: " + meanPackets);
    }

    //keep collecting cards until user has got a set obtained
    private static int CollectingCardsTest(int numCards) {
        int[] collectedCards = new int[numCards];
        int packetsBought = 0;
        
        //loop to keep collecting cards
        while (!hasCompleteSet(collectedCards)) {
            int newCard = getRandomCard(numCards);

         //checks if they have been given the same card
            if (collectedCards[newCard] == 0) {
                collectedCards[newCard] = 1;
            }

            packetsBought++;
        }

        return packetsBought;
    }

    //check if the user has a set of cards
    private static boolean hasCompleteSet(int[] collectedCards) {
        for (int card : collectedCards) {
            if (card == 0) {
                return false;
            }
        }
        return true;
    }

    //generate a random card number - modularity
    private static int getRandomCard(int numCards) {
        return (int) (Math.random() * numCards);
    }

    //calculate mean - modularity
    private static double calculateMean(int[] array) {
        int sum = 0;
        //loop to keep adding results to the sum
        for (int value : array) {
            sum += value;
        }
         //calculate mean
        return (double) sum / array.length;
    }
}
