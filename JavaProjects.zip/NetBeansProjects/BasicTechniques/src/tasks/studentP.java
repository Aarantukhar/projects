package tasks;

import java.util.ArrayList;
import java.util.Collections;

public class studentP {

    public static void main(String[] args) {
        
        ArrayList<String> studentNames;
        studentNames= new ArrayList<> ();
        //add values to array list
        studentNames.add("Santa");
        studentNames.add("Penjamin");
        studentNames.add("Leck");
        studentNames.add("Fanta");
        studentNames.add("Aaran");
        //pritning out all values
        System.out.println(studentNames);
        
          ArrayList<String> studentCopy;
        studentCopy= new ArrayList<> ();
        //add values to array list
        studentCopy.add("Santa");
        studentCopy.add("Penjamin");
        studentCopy.add("Leck");
        studentCopy.add("Fanta");
        studentCopy.add("Aaran");
      
        System.out.println("Duplicates");
        dupe(studentNames);
        dupe(studentNames);
        dupe(studentNames);
        dupe(studentNames);
        dupe(studentNames);
        System.out.println("No duplicates ---------");
        noDupe(studentNames);
         noDupe(studentNames);
          noDupe(studentNames);
           noDupe(studentNames);
           noDupe(studentNames);
           
          
            
      
      
     
       
        
     
    }

    private static void dupe(ArrayList<String> arrayList1){
         int length;
        length =  arrayList1.size();
     
       int random = (int)(Math.random() * length);
       
        System.out.println(arrayList1.get(random));
       
    }
    
    private static void noDupe(ArrayList<String> arrayList1){
         int length;
        length =  arrayList1.size();
     
       int random = (int)(Math.random() * length);
       
        System.out.println(arrayList1.get(random));
        
        arrayList1.remove(random);
        
}
    
   private static void reset(ArrayList<String> dest,ArrayList<String> source){
         Collections.copy(dest, source);
         System.out.println(dest);
        
    
}
}
