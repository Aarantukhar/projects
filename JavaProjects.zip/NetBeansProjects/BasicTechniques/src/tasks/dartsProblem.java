package tasks;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class dartsProblem {

    public static void main(String[] args) {
        String fileName = "\\\\tts-data2\\StudentData\\18ATukhar\\NetBeansProjects\\BasicTechniques\\src\\sample.txt";
        average(fileName);

    }

    static void average(String fileName) {
        ArrayList<String> array = new ArrayList<>();

        //get file 
        try {
            //get file
            File myObj = new File(fileName);
            //read file
            Scanner myReader = new Scanner(myObj);
            //add line to arraylist
            while (myReader.hasNextLine()) {
                array.add(myReader.nextLine());
                //sort
                Collections.sort(array);

            }
            int length = array.size();

            int count = 0;
            int score = 0;
            int biggest = 0;
            String associated = "";

            //iterate through
            for (int i = 0; i < length; i++) {
                String set = array.set(i, array.get(i));

                int temp = 0;
                temp = score;
                //get only the last 2 digits
                String partString = set.substring(0, 4);

                String sub = set.substring(5);
                score = Integer.parseInt(sub);
                if (score > temp) {
                    biggest = score;
                    associated = partString;

                } else {
                    biggest = temp;
                }

                //add score
                count = count + score;

            }
            count = count / length;

            System.out.println(count);
            System.out.println("Player with most 9 dart games  : ");
            System.out.println(associated);

        } catch (FileNotFoundException ex) {
            Logger.getLogger(passGen.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
