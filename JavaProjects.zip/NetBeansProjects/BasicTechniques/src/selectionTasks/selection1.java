/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selectionTasks;

import java.util.Scanner;

/**
 *
 * @author 18Atukhar
 */
public class selection1 {
        public static void main(String[] args) {
        Scanner sc;
        String letter;
        sc = new Scanner(System.in);
        letter = sc.nextLine();
        switch (letter) {
            case "A":
                System.out.println("80 points");
                break;
            case "B":
                System.out.println("70 points");
                break;
            case "C":
                System.out.println("60 points");
                break;
            case "D":
                System.out.println("50 points");
                break;
            case "E":
                System.out.println("40 points");
                break;
            default:
                System.out.println("No Points");
                break;

        }

    }

}


