
package arrays;

import java.util.Random;
public class arrayExample {

    
    public static void main(String[] args) {
      
      //to populate a 2d array we can use a nested loop
      int [][] examScores = new int [5][2];
      //populate array
      for (int i = 0 ; i < examScores.length;i++) {
          //iterate 2 times
          for (int j = 0;j < examScores[i].length;j++){
              //add value
              int distinctValues = 10;
              
              examScores[i][j] = (int) Math.random()* distinctValues ;
          }
          
         //print out a 2d array
          for (int[]examScore: examScores){
              for(int y : examScore){
                  System.out.print(i + " ");
                 
                  
              }
              System.out.println();
              
              
              
          }
      }
       
       
    }
    
}
