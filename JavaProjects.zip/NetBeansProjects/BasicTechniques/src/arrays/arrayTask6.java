
package arrays;

import java.util.Scanner;
public class arrayTask6 {

   
    public static void main(String[] args) {
        //gets user name
        String name;
        //getting input
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter name");
        //taking input
        name = sc.nextLine();
        //makes new array and converts name to individual characters
        char[] lets = name.toCharArray();
        sc.close();
        //loop to print array 
        for (int i = 0;i < lets.length; i +=2){
            System.out.print(lets[i]);
        }
        
        //count the a's 
        int countA = 0;
        for (char let:lets){
            if (let == 65 || let == 97){
                countA++;
            }
        }
        System.out.println("\nNumber of 'a's = " + countA);
      
        
    }
    
}
