package arrays;

public class threeDArrays {

    public static void main(String[] args) {
        //intialise variables 
        int size = 4;
        long[][][] arr = new long[size][size][size];
        int value = 0;
        int i;
        int j;
        int e;
        //populate array
        for (i = 0; i < arr.length; i++) {
            for (j = 0; j < arr[i].length; j++) {
                for (e = 0; e < arr[i][j].length; e++) {
                    arr[i][j][e] = (long) Math.pow(2, value);
                    value++;
                }
            }
        }
        
        //printing array
        for (i = 0; i < arr.length; i++) {
            for (j = 0; j < arr[i].length; j++) {
                for (e = 0; e < arr[i][j].length; e++) {
                    System.out.print(arr[i][j][e] + " ");

                }

            }
            //seperate lines
            System.out.print("\n");
        }
    }
}
