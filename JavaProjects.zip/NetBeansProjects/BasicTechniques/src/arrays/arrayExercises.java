
package arrays;

import java.util.Scanner;


public class arrayExercises {
     
    
    public static void main(String[] args) {
      
        Scanner sc;
        String name;
        sc = new Scanner (System.in);
        System.out.println("Enter a name: ");
        name = sc.nextLine();
        sc.close();
        name = name.toUpperCase();
        int lenName;
        lenName = name.length();
       
    
        int i;
        int [] values = null;

        for (i = 0;i < lenName; i++ ) {
            //get the characters of position i 
           values[i] = name.charAt(i);
        
    }
    
        int lenValues;
        lenValues = values.length;
        
        
        
        
        
        
}
   
    static void titleCase (int[] values) {
        int i;
        for (i = 0;i < values.length; i++ ) {
    }

        
        
    
    
    
    
    
    
    }
    
}


