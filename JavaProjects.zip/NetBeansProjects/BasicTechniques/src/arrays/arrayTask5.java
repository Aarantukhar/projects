package arrays;

import java.util.Random;

public class arrayTask5 {

    public static void main(String[] args) {
        //integer array
        int luckyDip[] = new int[6];
        int i;
        //adds random numbers
        Random rand = new Random();

        //for loop
        for (i = 0; i < 6; i++) {
            //random number generator
            int randomNum = rand.nextInt(60);
            luckyDip[i] = randomNum;
            System.out.println(luckyDip[i]);

        }
        //checks if any part of the array is equal to each other(extension)
         for(int x = 0; x < luckyDip.length; x++) {  
            for(int j = x + 1; j < luckyDip.length; j++) {  
                if(luckyDip[x] == luckyDip[j]) { 
                    int randomNum = rand.nextInt(60);
                    luckyDip[x] = randomNum;
                    
        
            }
            
        }
        }

        int temp = 0;
        int n = luckyDip.length;

        //go through the  array and checks if last value was bigger than the next
        for (int s = 0; s < n; s++) {
            for (int j = 1; j < (n - s); j++) {
                if (luckyDip[j - 1] > luckyDip[j]) {
                    //swap elements in the array
                    temp = luckyDip[j - 1];
                    luckyDip[j - 1] = luckyDip[j];
                    luckyDip[j] = temp;

                }
            }

        }
       
        
        
        
        System.out.println("Here is your lucky dip");

        //printing array
        for (int z = 0; z < n; z++) {
            System.out.println(luckyDip[z]);
            

        }
    
}
        }

