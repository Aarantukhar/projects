package usingScanner;

import java.util.Scanner;

public class ScannerExercise {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String word;

        System.out.print("Enter stuff: ");
        word = sc.nextLine();

        sc.close();

        System.out.println(word);
    }
}
