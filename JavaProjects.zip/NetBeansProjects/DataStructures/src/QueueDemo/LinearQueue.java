package QueueDemo;

public class LinearQueue {
    //attributes
     private int[] arr;
     private int front;
     private int rear;
     private int maxSize;
     private int currentSize;
     
     //constructor
     LinearQueue(){
        this.maxSize = 5;
        this.arr = new int[maxSize];
        //points at the first item in the queue
        this.front = 0;
        //points at the last item in the queue
        this.rear = -1;
        this.currentSize = 0; 
        
     }
     //method
     // add - enqueue
     public void enqueue(int value){
         //testing for queue full
         if (isFull()) {
             System.out.println("Error - queue full");
         } else{
             //sucessfull adding to the queue
             System.out.println("Item added");
        this.rear++;
        this.arr[rear] = value;
        this.currentSize++;
         }
        
         
     }
     // remove - dequeue
     public int dequeue(){
         if (isEmpty()) {
             System.out.println("Error - the queue is empty");
             return -1;
         } else{
             //get the value at the front of the queue
             int value = this.arr[front];
             this.front++;
             //this.currentSize--; NOT DONE IN LINEAR QUEUE
             return value;
             
         }
     }

     // check empty - isEmpty
     public boolean isEmpty(){
         return this.front > this.rear;
     }
     
     //check full - isFull
     public boolean isFull(){
         return this.currentSize == this.maxSize;
     }
     //print the conentents
    public String toString(){
        String temp = "";
        temp += "Current State of queue\n";
        temp+= "Front = " + this.front + "\n";
        temp+= "Rear = " + this.rear + "\n";
        
        for (int i = 0; i < this.maxSize; i++) {
            temp += "At location " + i + " = " + this.arr[i] + "\n";
            
        }
        
        return temp;
    }
    
}
