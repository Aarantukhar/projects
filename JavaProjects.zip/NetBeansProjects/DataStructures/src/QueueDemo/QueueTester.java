package QueueDemo;

public class QueueTester {

    public static void main(String[] args) {
        //create a queue object
        LinearQueue myQueue = new LinearQueue();
        
        //test is empty
        System.out.println("Queue empty = " + myQueue.isEmpty());

        myQueue.enqueue(17);
        myQueue.enqueue(31);
        myQueue.enqueue(3);
        System.out.println("Queue empty = " + myQueue.isEmpty());
        
        //myQueue.enqueue(7);
        //myQueue.enqueue(19);
        //myQueue.enqueue(23);
        System.out.println(myQueue);
        
        System.out.println("Value being dequeued  = " +
                myQueue.dequeue());
        System.out.println("Value being dequeued  = " +
                myQueue.dequeue());
        System.out.println("Value being dequeued  = " +
                myQueue.dequeue());
        System.out.println("Value being dequeued  = " +
                myQueue.dequeue());
        System.out.println("Value being dequeued  = " +
                myQueue.dequeue());
        System.out.println("Value being dequeued  = " +
                myQueue.dequeue());
                
    }

}
