package StackDemo;

class CharStack {

    //attributes - private enforces encapsulation
    private int maxSize;
    private char[] arr;
    private int top;

    //constructors
    CharStack() {
        this.maxSize = 6;
        this.arr = new char[this.maxSize];
        this.top = -1; // points at the element at the top of the array
        System.out.println("New empty stack created");
    }
    
    CharStack(int size){
        this.maxSize = size;
        this.arr = new char [this.maxSize];
        this.top = -1;
        System.out.println("New empty stack created");
        
         
    }

    //method
    public void push(char letter) {
        if (!isFull()) {
            //increment top before pushing content
            this.top++;
            this.arr[this.top] = letter;
            System.out.println("Stack contents updated - push carried out");
        } else {
            System.out.println("Error! Stack full");
        }
    }

    public char pop() {
        //testing for non-empty stack
        if (!isEmpty()) {
            // get character from top of stack
            char output = this.arr[top];
            this.top--;
            System.out.println("Pop carried out sucessfully");
            return output;

        } else {
            System.out.println("Error! Stack is empty");
        }
        return ' ';
    }

    public boolean isFull() {
        return this.top == this.maxSize - 1;

    }

    public boolean isEmpty() {
        return this.top == -1;

    }

    public char peek() {
        // looking at the top of the stack without removing it
        if (!isEmpty()) {
            return this.arr[top];

        } else {
            System.out.println("Error! Empty stack");
        }
        return ' ';
    }

}
