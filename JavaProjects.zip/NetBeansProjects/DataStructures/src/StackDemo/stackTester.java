package StackDemo;

public class stackTester {

    public static void main(String[] args) {
       //create an empty stack of char
       CharStack letters = new CharStack(4);
        
        //testing methods
        System.out.println("Is the stack empty? " +  letters.isEmpty());
        System.out.println("Is the stack empty? " +  letters.isEmpty());
        letters.push('R');
        letters.push('O');
        letters.push('B');
        letters.push('E');
        letters.push('R');
        letters.push('T');
        
        System.out.println("Is the stack empty? " +  letters.isEmpty());
        System.out.println("Is the stack empty? " +  letters.isEmpty());
        
        letters.push('x');
        
        System.out.println(letters.pop());
        System.out.println(letters.pop());
        System.out.println(letters.pop());
        System.out.println(letters.pop());
        System.out.println(letters.pop());
        System.out.println(letters.pop());
        System.out.println(letters.pop());
        System.out.println(letters.pop());
        
        
        
    }
    
}
        
