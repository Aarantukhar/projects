
package objectyear12;


public class HumanTester {

   
    public static void main(String[] args) {
        //create an object of type human
        //class human starts with capital
        //object aaran starts with a lower case letter
        Human aaran = new Human(16,"Aaran", "Tukhar", "Male");
        //set attributes of aaran
        aaran.setFirstName("Aaran");
        aaran.setLastName("Tukhar");
        
        aaran.setGender("Male");
        //print
        System.out.println("Humans first name is " + aaran.getFirstName());
        System.out.println("Last name is " + aaran.getLastName());
        System.out.println("Age is " + aaran.getAge());
        System.out.println("Gender = " + aaran.getGender());
        System.out.println(aaran.toString());
        
        
        
        

    }
    
   
    
        
    

}
