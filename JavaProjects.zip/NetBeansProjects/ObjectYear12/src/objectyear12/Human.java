
package objectyear12;

//a class is a template/blueprint for many objects to be created
class Human {
    /*
    ENCAPSULATION - a principle techinique used in OOP where the attributes
    (state) and the behaviour (methods) of an object of a given class are
    represented (wrapped) in one construct.
    
    Attributes are set to private to ensure no direct change of state is 
    allowed.
    Attributes change and access is enabled through getters and setters
    */
    
    //attributes
    private String firstName;
    private String lastName;
    private int age;
    private String gender;
  
    
    //constructor - run first
    Human(){
        System.out.println("new human created");
        //default settings.
        this.firstName = "unknown";
        this.lastName = "unknown";
        this.age = 0;
        this.gender = "unknown";
       
    }
    //final constructor  - sets all
    Human(int currentAge, String fName, String lName, String gend){
        System.out.println("new human created with custom age");
        //default settings.
        this.firstName = fName;
        this.lastName = lName;
        this.age = currentAge;
        this.gender = gend;
       
    }
    //additional methods
    //setters - allowing the user to change specific attributes
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
     
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    public void setGender(String gend){
        this.gender = gend;
    }

    //getters allows access to state of attribue

public String getFirstName(){
    return this.firstName;
}
public String getLastName(){
    return this.lastName;
}
public int getAge(){
    return this.age;
    
}

public String getGender(){
    return this.gender;
}
//toString method - convienient method to show all states of object
    @Override
    public String toString(){
    String info;
    info = "Human info: \nName = " + this.firstName + " " + this.lastName;
    info += "\nGender = " + this.gender;
    info += "\nAge = " + this.age;
    return info;
    
}
}
    
    



